package com.registration.captcher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaptcherApplication {

	public static void main(String[] args) {
		SpringApplication.run(CaptcherApplication.class, args);
	}

}
